<template>
  <div>
    <h1>{{ msg }}</h1>
    <h2>Onze gewaardeerde klanten</h2>
    <ul>
      <li>Microsoft</li>
      <li>Google</li>
      <li>Facebook</li>
      <li>Twitter</li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    msg: String
  }
}
</script>

<style scoped>
div {
  text-align: left;
}

</style>