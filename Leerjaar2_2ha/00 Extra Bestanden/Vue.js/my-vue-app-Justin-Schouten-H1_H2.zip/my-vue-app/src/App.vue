<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <HelloWorld msg="Dit is mijn eerste Vue-App!"/>
    <hello-world name="Justin Schouten"/>
    <CustomerList msg="Dit is mijn 2de Vue-App!"/>
    <EigenInfo msg="Dit is mijn 3de Vue-App!"></EigenInfo>
    <EigenInfo firstname="Justin"></EigenInfo>
    <EigenInfo lastname="Schouten"></EigenInfo>
    <EigenInfo age="22"></EigenInfo>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import CustomerList from './components/CustomerList.vue'
import EigenInfo from "@/components/EigenInfo";

export default {
  name: 'App',
  components: {
    EigenInfo,
    HelloWorld,
    CustomerList
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
