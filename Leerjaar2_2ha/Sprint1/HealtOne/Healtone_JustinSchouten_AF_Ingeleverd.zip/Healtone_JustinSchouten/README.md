@author Justin Schouten <br>
Klas: 2ha

<b>Healt one Project</b>
<hr>

use: mvc
<hr>

1. opstarten met index_login.php
2. je kan inloggen met admin, admin of justin, justin

(Het hele project werkt nog niet optimaal)

(perongeluk bestanden kapot getrokken met het toevoegen van de login, regForm en view/View.php -> medicijnen)

